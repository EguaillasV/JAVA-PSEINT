const leer = require ("prompt-sync")()
const escribir = console 
class algoritmo {
    algoritmo21(){
        for (let i = 1; i <= 10; i++) {
            escribir.log(i);
        }
    
    }
}    
let a = new algoritmo ()
a.algoritmo21 ()